// save_feedback.php
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $feedback = $_POST['feedback'];

    // Connect to your MySQL database
    $conn = new mysqli('localhost', 'username', 'password', 'exam');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert feedback into the database
    $stmt = $conn->prepare("INSERT INTO feedback (name, email, feedback) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $feedback);
    $stmt->execute();

    // Close the database connection
    $stmt->close();
    $conn->close();

    echo "Feedback saved successfully!";
}
?>
