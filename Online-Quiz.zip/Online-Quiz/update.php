<?php
  include_once 'database.php';
  session_start();

  // Ensure session key and email are set before proceeding
  if (!isset($_SESSION['email'])) {
      // Redirect to login page if the user is not logged in
      header("Location: login.php");
      exit();
  }

  $email = $_SESSION['email'];

  // Check if the session key is correct
  if (isset($_SESSION['key']) && $_SESSION['key'] == 'suryapinky') {

      // Handling email deletion if the session key is correct
      if (isset($_GET['demail'])) {
          $demail = $_GET['demail'];
          $stmt = mysqli_prepare($con, "DELETE FROM rank WHERE email=?");
          mysqli_stmt_bind_param($stmt, "s", $demail);
          mysqli_stmt_execute($stmt);

          $stmt = mysqli_prepare($con, "DELETE FROM history WHERE email=?");
          mysqli_stmt_bind_param($stmt, "s", $demail);
          mysqli_stmt_execute($stmt);

          $stmt = mysqli_prepare($con, "DELETE FROM user WHERE email=?");
          mysqli_stmt_bind_param($stmt, "s", $demail);
          mysqli_stmt_execute($stmt);

          header("Location: dashboard.php?q=1");
          exit();
      }

      // Handling quiz deletion
      if (isset($_GET['q']) && $_GET['q'] == 'rmquiz') {
          $eid = $_GET['eid'];

          // Remove all questions, options, and answers related to the quiz
          $result = mysqli_query($con, "SELECT qid FROM questions WHERE eid='$eid'");
          while ($row = mysqli_fetch_array($result)) {
              $qid = $row['qid'];
              mysqli_query($con, "DELETE FROM options WHERE qid='$qid'");
              mysqli_query($con, "DELETE FROM answer WHERE qid='$qid'");
          }

          mysqli_query($con, "DELETE FROM questions WHERE eid='$eid'");
          mysqli_query($con, "DELETE FROM quiz WHERE eid='$eid'");
          mysqli_query($con, "DELETE FROM history WHERE eid='$eid'");

          header("Location: dashboard.php?q=5");
          exit();
      }

      // Handling adding new quiz
      if (isset($_GET['q']) && $_GET['q'] == 'addquiz') {
          $name = ucwords(strtolower($_POST['name']));
          $total = $_POST['total'];
          $sahi = $_POST['right'];
          $wrong = $_POST['wrong'];
          $id = uniqid();

          $stmt = mysqli_prepare($con, "INSERT INTO quiz (eid, name, sahi, wrong, total, date) VALUES(?, ?, ?, ?, ?, NOW())");
          mysqli_stmt_bind_param($stmt, "ssiii", $id, $name, $sahi, $wrong, $total);
          mysqli_stmt_execute($stmt);

          header("Location: dashboard.php?q=4&step=2&eid=$id&n=$total");
          exit();
      }

      // Handling adding questions
      if (isset($_GET['q']) && $_GET['q'] == 'addqns') {
          $n = $_GET['n'];
          $eid = $_GET['eid'];

          for ($i = 1; $i <= $n; $i++) {
              $qid = uniqid();
              $qns = $_POST['qns' . $i];
              $ch = $_GET['ch'];

              $stmt = mysqli_prepare($con, "INSERT INTO questions (eid, qid, question, choice, sn) VALUES(?, ?, ?, ?, ?)");
              mysqli_stmt_bind_param($stmt, "ssssi", $eid, $qid, $qns, $ch, $i);
              mysqli_stmt_execute($stmt);

              // Insert options and answers
              $oaid = uniqid();
              $obid = uniqid();
              $ocid = uniqid();
              $odid = uniqid();

              $a = $_POST[$i . '1'];
              $b = $_POST[$i . '2'];
              $c = $_POST[$i . '3'];
              $d = $_POST[$i . '4'];

              mysqli_query($con, "INSERT INTO options (qid, option, option_id) VALUES('$qid', '$a', '$oaid')");
              mysqli_query($con, "INSERT INTO options (qid, option, option_id) VALUES('$qid', '$b', '$obid')");
              mysqli_query($con, "INSERT INTO options (qid, option, option_id) VALUES('$qid', '$c', '$ocid')");
              mysqli_query($con, "INSERT INTO options (qid, option, option_id) VALUES('$qid', '$d', '$odid')");

              $e = $_POST['ans' . $i];
              $ansid = ($e == 'a') ? $oaid : (($e == 'b') ? $obid : (($e == 'c') ? $ocid : $odid));
              mysqli_query($con, "INSERT INTO answer (qid, ansid) VALUES('$qid', '$ansid')");
          }

          header("Location: dashboard.php?q=0");
          exit();
      }

      // Handling quiz result submission
      if (isset($_GET['q']) && $_GET['q'] == 'quiz' && isset($_GET['step']) && $_GET['step'] == 2) {
          $eid = $_GET['eid'];
          $sn = $_GET['n'];
          $total = $_GET['t'];
          $ans = $_POST['ans'];
          $qid = $_GET['qid'];

          // Check if the answer is correct
          $q = mysqli_query($con, "SELECT ansid FROM answer WHERE qid='$qid'");
          while ($row = mysqli_fetch_array($q)) {
              $ansid = $row['ansid'];
          }

          if ($ans == $ansid) {
              // Correct answer logic
              $q = mysqli_query($con, "SELECT sahi FROM quiz WHERE eid='$eid'");
              while ($row = mysqli_fetch_array($q)) {
                  $sahi = $row['sahi'];
              }

              if ($sn == 1) {
                  mysqli_query($con, "INSERT INTO history (email, eid, score, level, sahi, wrong, date) VALUES('$email', '$eid', 0, 0, 0, 0, NOW())");
              }

              $q = mysqli_query($con, "SELECT score, sahi FROM history WHERE eid='$eid' AND email='$email'");
              while ($row = mysqli_fetch_array($q)) {
                  $s = $row['score'];
                  $r = $row['sahi'];
              }

              $r++;
              $s = $s + $sahi;
              mysqli_query($con, "UPDATE history SET score=$s, level=$sn, sahi=$r, date=NOW() WHERE email='$email' AND eid='$eid'");
          } else {
              // Wrong answer logic
              $q = mysqli_query($con, "SELECT wrong FROM quiz WHERE eid='$eid'");
              while ($row = mysqli_fetch_array($q)) {
                  $wrong = $row['wrong'];
              }

              if ($sn == 1) {
                  mysqli_query($con, "INSERT INTO history (email, eid, score, level, sahi, wrong, date) VALUES('$email', '$eid', 0, 0, 0, 0, NOW())");
              }

              $q = mysqli_query($con, "SELECT score, wrong FROM history WHERE eid='$eid' AND email='$email'");
              while ($row = mysqli_fetch_array($q)) {
                  $s = $row['score'];
                  $w = $row['wrong'];
              }

              $w++;
              $s = $s - $wrong;
              mysqli_query($con, "UPDATE history SET score=$s, level=$sn, wrong=$w, date=NOW() WHERE email='$email' AND eid='$eid'");
          }

          // Next question or result
          if ($sn != $total) {
              $sn++;
              header("Location: welcome.php?q=quiz&step=2&eid=$eid&n=$sn&t=$total");
              exit();
          } else {
              $q = mysqli_query($con, "SELECT score FROM history WHERE eid='$eid' AND email='$email'");
              while ($row = mysqli_fetch_array($q)) {
                  $s = $row['score'];
              }

              $q = mysqli_query($con, "SELECT * FROM rank WHERE email='$email'");
              $rowcount = mysqli_num_rows($q);

              if ($rowcount == 0) {
                  mysqli_query($con, "INSERT INTO rank (email, score, time) VALUES('$email', '$s', NOW())");
              } else {
                  while ($row = mysqli_fetch_array($q)) {
                      $sun = $row['score'];
                  }
                  $sun = $s + $sun;
                  mysqli_query($con, "UPDATE rank SET score=$sun, time=NOW() WHERE email='$email'");
              }

              header("Location: welcome.php?q=result&eid=$eid");
              exit();
          }
      }
  }
?>
