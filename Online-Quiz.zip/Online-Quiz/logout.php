<?php
session_start();
date_default_timezone_set("Asia/Kolkata"); // Adjust timezone if needed
$logout_time = date("Y-m-d H:i:s");
echo "Logout Time: " . $logout_time . "<br>";
echo "Login Time: " . $_SESSION['login_time'] . "<br>";
session_unset();
session_destroy();
?>
<a href='login.php'>Login Again</a>
