<?php
session_start();
date_default_timezone_set("Asia/Kolkata");

// Set login time if not already set
if (!isset($_SESSION['login_time'])) {
    $_SESSION['login_time'] = date("Y-m-d H:i:s");
}

// Handle login count with a cookie
if (isset($_COOKIE['login_count'])) {
    $login_count = $_COOKIE['login_count'] + 1;
} else {
    $login_count = 1;
}


// Update the cookie (expires in 30 days)
setcookie('login_count', $login_count, time() + (30 * 24 * 60 * 60));

// Display information
echo "<div style='padding:10px; font-family:Arial;'>";
echo "<p><strong>Login Time:</strong> " . $_SESSION['login_time'] . "</p>";
echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";
echo "<p><strong>Total Logins (via cookie):</strong> " . $login_count . "</p>";
echo "</div>";
?>



<style>
#paymentButton {
    background-color: #4d94ff;
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    float: right;
    margin-top: -40px;
    margin-right: 20px;
}

#payment-section {
    margin-top: 20px;
    border: 1px solid #ccc;
    padding: 20px;
    border-radius: 10px;
    background-color: #f9f9f9;
    width: 60%;
    margin-left: auto;
    margin-right: auto;
}
</style>

<button id="paymentButton" onclick="loadPayment()">Payment</button>

<div id="ajaxContent"></div>

<script>
function loadPayment() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "payment/payment.html", true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("ajaxContent").innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}
</script>



<?php
    include_once 'database.php';
    
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        include_once 'database.php';
    }
?>


<!-- Search Bar -->
<div style="text-align:center; margin-bottom: 20px;">
    <input type="text" id="quizSearch" onkeyup="filterQuizzes()" placeholder="Search quizzes by title..." style="width: 50%; padding: 10px; font-size: 16px; border-radius: 8px; border: 1px solid #ccc;">
</div>

<!-- JavaScript -->
<script>
function filterQuizzes() {
    var input = document.getElementById("quizSearch");
    var filter = input.value.toUpperCase();
    var table = document.querySelector(".table");
    var tr = table.getElementsByTagName("tr");

    // Start from 1 to skip the table header
    for (var i = 1; i < tr.length; i++) {
        var td = tr[i].getElementsByTagName("td")[1]; // Assuming 2nd column is the title
        if (td) {
            var txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }       
    }
}
</script>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome | Online Quiz System</title>
    <link  rel="stylesheet" href="css/bootstrap.min.css"/>
    <link  rel="stylesheet" href="css/bootstrap-theme.min.css"/>    
    <link rel="stylesheet" href="css/welcome.css">
    <link  rel="stylesheet" href="css/font.css">
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"  type="text/javascript"></script>
    

</head>
<body>



    <nav class="navbar navbar-default title1">
        <div class="container-fluid">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        <a class="navbar-brand" href="#"><b>Online Quiz System</b></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav navbar-left">
            <li <?php if(@$_GET['q']==1) echo'class="active"'; ?> ><a href="welcome.php?q=1"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>&nbsp;Home<span class="sr-only">(current)</span></a></li>
            <li <?php if(@$_GET['q']==2) echo'class="active"'; ?>> <a href="welcome.php?q=2"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>&nbsp;History</a></li>
            <li <?php if(@$_GET['q']==3) echo'class="active"'; ?>> <a href="welcome.php?q=3"><span class="glyphicon glyphicon-stats" aria-hidden="true"></span>&nbsp;Ranking</a></li>
            
        </ul>
        <ul class="nav navbar-nav navbar-right">
        <li <?php echo''; ?> > <a href="logout.php?q=welcome.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>&nbsp;Log out</a></li>
        </ul>
        
            
           
       
        </div>
    </div>
    </nav>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(@$_GET['q']==1) 
                {
                    $result = mysqli_query($con,"SELECT * FROM quiz ORDER BY date DESC") or die('Error');
                    echo  '<div class="panel"><div class="table-responsive"><table class="table table-striped title1">
                    <tr><td><center><b>S.N.</b></center></td><td><center><b>Topic</b></center></td><td><center><b>Total question</b></center></td><td><center><b>Marks</center></b></td><td><center><b>Action</b></center></td></tr>';
                    $c=1;
                    while($row = mysqli_fetch_array($result)) {
                        $title = $row['title'];
                        $total = $row['total'];
                        $sahi = $row['sahi'];
                        $eid = $row['eid'];
                    $q12=mysqli_query($con,"SELECT score FROM history WHERE eid='$eid' AND email='$email'" )or die('Error98');
                    $rowcount=mysqli_num_rows($q12);	
                    if($rowcount == 0){
                        echo '<tr><td><center>'.$c++.'</center></td><td><center>'.$title.'</center></td><td><center>'.$total.'</center></td><td><center>'.$sahi*$total.'</center></td><td><center><b><a href="welcome.php?q=quiz&step=2&eid='.$eid.'&n=1&t='.$total.'" class="btn sub1" style="color:black;margin:0px;background:#1de9b6"><span class="glyphicon glyphicon-new-window" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Start</b></span></a></b></center></td></tr>';
                    }
                    else
                    {
                    echo '<tr style="color:#99cc32"><td><center>'.$c++.'</center></td><td><center>'.$title.'&nbsp;<span title="This quiz is already solve by you" class="glyphicon glyphicon-ok" aria-hidden="true"></span></center></td><td><center>'.$total.'</center></td><td><center>'.$sahi*$total.'</center></td><td><center><b><a href="update.php?q=quizre&step=25&eid='.$eid.'&n=1&t='.$total.'" class="pull-right btn sub1" style="color:black;margin:0px;background:red"><span class="glyphicon glyphicon-repeat" aria-hidden="true"></span>&nbsp;<span class="title1"><b>Restart</b></span></a></b></center></td></tr>';
                    }
                    }
                    $c=0;
                    echo '</table></div></div>';
                }?>

                <?php
                    if(@$_GET['q']== 'quiz' && @$_GET['step']== 2) 
                    {
                        $eid=@$_GET['eid'];
                        $sn=@$_GET['n'];
                        $total=@$_GET['t'];
                        $q=mysqli_query($con,"SELECT * FROM questions WHERE eid='$eid' AND sn='$sn' " );
                        echo '<div class="panel" style="margin:5%">';
                        while($row=mysqli_fetch_array($q) )
                        {
                            $qns=$row['qns'];
                            $qid=$row['qid'];
                            echo '<b>Question &nbsp;'.$sn.'&nbsp;::<br /><br />'.$qns.'</b><br /><br />';
                        }
                        $q=mysqli_query($con,"SELECT * FROM options WHERE qid='$qid' " );
                        echo '<form action="update.php?q=quiz&step=2&eid='.$eid.'&n='.$sn.'&t='.$total.'&qid='.$qid.'" method="POST"  class="form-horizontal">
                        <br />';

                        while($row=mysqli_fetch_array($q) )
                        {
                            $option=$row['option'];
                            $optionid=$row['optionid'];
                            echo'<input type="radio" name="ans" value="'.$optionid.'">&nbsp;'.$option.'<br /><br />';
                        }
                        echo'<br /><button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-lock" aria-hidden="true"></span>&nbsp;Submit</button></form></div>';
                    }

                    if(@$_GET['q']== 'result' && @$_GET['eid']) 
                    {
                        $eid=@$_GET['eid'];
                        $q=mysqli_query($con,"SELECT * FROM history WHERE eid='$eid' AND email='$email' " )or die('Error157');
                        echo  '<div class="panel">
                        <center><h1 class="title" style="color:#660033">Result</h1><center><br /><table class="table table-striped title1" style="font-size:20px;font-weight:1000;">';

                        while($row=mysqli_fetch_array($q) )
                        {
                            $s=$row['score'];
                            $w=$row['wrong'];
                            $r=$row['sahi'];
                            $qa=$row['level'];
                            echo '<tr style="color:#66CCFF"><td>Total Questions</td><td>'.$qa.'</td></tr>
                                <tr style="color:#99cc32"><td>right Answer&nbsp;<span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span></td><td>'.$r.'</td></tr> 
                                <tr style="color:red"><td>Wrong Answer&nbsp;<span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span></td><td>'.$w.'</td></tr>
                                <tr style="color:#66CCFF"><td>Score&nbsp;<span class="glyphicon glyphicon-star" aria-hidden="true"></span></td><td>'.$s.'</td></tr>';
                        }
                        $q=mysqli_query($con,"SELECT * FROM rank WHERE  email='$email' " )or die('Error157');
                        while($row=mysqli_fetch_array($q) )
                        {
                            $s=$row['score'];
                            echo '<tr style="color:#990000"><td>Overall Score&nbsp;<span class="glyphicon glyphicon-stats" aria-hidden="true"></span></td><td>'.$s.'</td></tr>';
                        }
                        echo '</table></div>';
                    }
                ?>

                <?php
                    if(@$_GET['q']== 2) 
                    {
                        $q=mysqli_query($con,"SELECT * FROM history WHERE email='$email' ORDER BY date DESC " )or die('Error197');
                        echo  '<div class="panel title">
                        <table class="table table-striped title1" >
                        <tr style="color:black;"><td><center><b>S.N.</b></center></td><td><center><b>Quiz</b></center></td><td><center><b>Question Solved</b></center></td><td><center><b>Right</b></center></td><td><center><b>Wrong<b></center></td><td><center><b>Score</b></center></td>';
                        $c=0;
                        while($row=mysqli_fetch_array($q) )
                        {
                        $eid=$row['eid'];
                        $s=$row['score'];
                        $w=$row['wrong'];
                        $r=$row['sahi'];
                        $qa=$row['level'];
                        $q23=mysqli_query($con,"SELECT title FROM quiz WHERE  eid='$eid' " )or die('Error208');

                        while($row=mysqli_fetch_array($q23) )
                        {  $title=$row['title'];  }
                        $c++;
                        echo '<tr><td><center>'.$c.'</center></td><td><center>'.$title.'</center></td><td><center>'.$qa.'</center></td><td><center>'.$r.'</center></td><td><center>'.$w.'</center></td><td><center>'.$s.'</center></td></tr>';
                        }
                        echo'</table></div>';
                    }

                    if(@$_GET['q']== 3) 
                    {
                        $q=mysqli_query($con,"SELECT * FROM rank ORDER BY score DESC " )or die('Error223');
                        echo  '<div class="panel title"><div class="table-responsive">
                        <table class="table table-striped title1" >
                        <tr style="color:red"><td><center><b>Rank</b></center></td><td><center><b>Name</b></center></td><td><center><b>Email</b></center></td><td><center><b>Score</b></center></td></tr>';
                        $c=0;

                        while($row=mysqli_fetch_array($q) )
                        {
                            $e=$row['email'];
                            $s=$row['score'];
                            $q12=mysqli_query($con,"SELECT * FROM user WHERE email='$e' " )or die('Error231');
                            while($row=mysqli_fetch_array($q12) )
                            {
                                $name=$row['name'];
                            }
                            $c++;
                            echo '<tr><td style="color:black"><center><b>'.$c.'</b></center></td><td><center>'.$name.'</center></td><td><center>'.$e.'</center></td><td><center>'.$s.'</center></td></tr>';
                        }
                        echo '</table></div></div>';
                    }
                ?>

<!-- Chatbot Toggle Button -->
<div id="chatbot-icon" onclick="toggleChatbot()">💬</div>

<!-- Chatbot Window -->
<div id="chatbot-box">
    <div id="chatbot-header">QuizBot 🤖 
        <span onclick="toggleChatbot()" style="float:right;cursor:pointer;">✖</span>
    </div>
    <div id="chatbot-messages"></div>
    <input type="text" id="chatbot-input" placeholder="Ask something..." 
           onkeydown="if(event.key==='Enter') sendMessage()">
</div>

<style>
#chatbot-icon {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #1de9b6;
    padding: 15px;
    border-radius: 50%;
    cursor: pointer;
    font-size: 24px;
    box-shadow: 2px 2px 10px gray;
}
#chatbot-box {
    display: none;
    position: fixed;
    bottom: 80px;
    right: 20px;
    width: 300px;
    background: white;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 2px 2px 10px gray;
    overflow: hidden;
    z-index: 9999;
}
#chatbot-header {
    background: #1de9b6;
    padding: 10px;
    color: white;
    font-weight: bold;
}
#chatbot-messages {
    max-height: 250px;
    overflow-y: auto;
    padding: 10px;
    font-size: 14px;
}
#chatbot-input {
    width: 100%;
    border: none;
    padding: 10px;
    border-top: 1px solid #ddd;
}
.question-btn {
    display: block;
    background-color: #1de9b6;
    color: white;
    padding: 8px;
    margin: 5px 0;
    border: none;
    width: 100%;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
    font-size: 14px;
}
.question-btn:hover {
    background-color: #17c1a7;
}
</style>

<script>
function toggleChatbot() {
    var box = document.getElementById('chatbot-box');
    box.style.display = box.style.display === 'none' ? 'block' : 'none';
}

function sendMessage() {
    var input = document.getElementById('chatbot-input');
    var msg = input.value.trim();
    if (msg === '') return;

    var chat = document.getElementById('chatbot-messages');
    chat.innerHTML += "<div><b>You:</b> " + msg + "</div>";
    input.value = '';

    const lowerMsg = msg.toLowerCase();
    let response = "Sorry, I don't understand.";

    // Questions and answers mapping
    const questionsAndAnswers = [
        { question: "How to attempt the quiz?", answer: "To attempt the quiz, go to the Home tab and select a quiz. Then, choose your answers and submit." },
        { question: "What are the quiz instructions?", answer: "The quiz consists of 10 questions with 4 options each. You must answer within 10 minutes." },
        { question: "How to start the quiz?", answer: "Simply click on any quiz listed in the Home tab to begin." },
        { question: "Where can I view the results?", answer: "You can view your results in the Result tab." },
        { question: "What is the time limit for the quiz?", answer: "The time limit is 10 minutes for the entire quiz." },
        { question: "How many questions are there in the quiz?", answer: "Each quiz consists of 10 questions." },
        { question: "How do I submit my answers?", answer: "After answering all questions, click the 'Submit' button to finish the quiz." },
        { question: "What is the marking scheme?", answer: "For each correct answer, you earn 3 marks. Incorrect answers will have negative marking." },
        { question: "What happens if I answer incorrectly?", answer: "For each incorrect answer, you will lose marks due to negative marking." },
        { question: "Can I retry the quiz?", answer: "You can retry the quiz by clicking on the quiz again in the Home tab." }
    ];

    // If the message is a number between 1 and 10, return the corresponding answer
    if (/^[1-9]$|^10$/.test(msg)) {
        const questionNumber = parseInt(msg) - 1; // Subtract 1 to get the correct index
        response = `<b>Answer:</b> ${questionsAndAnswers[questionNumber].answer}`;
    }
    // Greeting message
    else if (/hi|hello/.test(lowerMsg)) {
        response = "Hello! I'm QuizBot. Ask me anything about this quiz system.";
        displayQuestions(chat);
    }

    chat.innerHTML += "<div><b>QuizBot:</b> " + response + "</div>";
    chat.scrollTop = chat.scrollHeight;
}

// Function to display numbered questions
function displayQuestions(chat) {
    const questionsAndAnswers = [
        "How to attempt the quiz?",
        "What are the quiz instructions?",
        "How to start the quiz?",
        "Where can I view the results?",
        "What is the time limit for the quiz?",
        "How many questions are there in the quiz?",
        "How do I submit my answers?",
        "What is the marking scheme?",
        "What happens if I answer incorrectly?",
        "Can I retry the quiz?"
    ];

    questionsAndAnswers.forEach(function (question, index) {
        chat.innerHTML += `<button class="question-btn" onclick="sendMessageFromButton('${index + 1}')">${index + 1}. ${question}</button>`;
    });
}

// Function to handle the click event from the question buttons
function sendMessageFromButton(questionNumber) {
    var chat = document.getElementById('chatbot-messages');
    chat.innerHTML += "<div><b>You:</b> " + questionNumber + "</div>";

    // Call sendMessage to handle the question and get the response
    var input = document.getElementById('chatbot-input');
    input.value = questionNumber;
    sendMessage();
}
</script>




</body>
</html>