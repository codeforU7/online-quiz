function loadPaymentOptions() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "payment/payment-options.json", true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            var data = JSON.parse(xhr.responseText);
            var select = document.getElementById("payment-options");

            data.options.forEach(function (option) {
                var opt = document.createElement("option");
                opt.value = option.type;
                opt.textContent = option.type;
                select.appendChild(opt);
            });

            // Store full data for use on selection
            select.dataset.fullOptions = JSON.stringify(data.options);
        }
    };
    xhr.send();
}

document.getElementById("payment-options").addEventListener("change", function () {
    var selectedMethod = this.value;
    var fullOptions = JSON.parse(this.dataset.fullOptions);
    var cardTypeSelect = document.getElementById("cardType");

    // Clear previous options
    cardTypeSelect.innerHTML = "";
    cardTypeSelect.style.display = "none";

    // Find selected method in fullOptions
    fullOptions.forEach(function (option) {
        if (option.type === selectedMethod && option.cardTypes) {
            cardTypeSelect.style.display = "inline-block";
            var defaultOption = document.createElement("option");
            defaultOption.value = "";
            defaultOption.textContent = "--Select Card Type--";
            cardTypeSelect.appendChild(defaultOption);

            option.cardTypes.forEach(function (type) {
                var opt = document.createElement("option");
                opt.value = type;
                opt.textContent = type;
                cardTypeSelect.appendChild(opt);
            });
        }
    });
});

function makePayment() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "payment/payment-response.xml", true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            var responseXML = xhr.responseXML;
            var message = responseXML.getElementsByTagName("message")[0].textContent;
            document.getElementById("payment-response").innerHTML =
                "<p style='color:green;'>" + message + "</p>";
        }
    };
    xhr.send();
}
