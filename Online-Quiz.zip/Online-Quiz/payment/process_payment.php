<?php
header("Content-Type: application/json");

// Read and decode JSON input
$data = json_decode(file_get_contents("php://input"));

// Extract values with fallbacks
$method = $data->method ?? 'Unknown';
$amount = $data->amount ?? 0;
$remarks = $data->remarks ?? '';
$cardType = $data->cardType ?? '';

// Prepare response message
$message = "Payment of ₹" . $amount . " via " . $method;

// Include card type if applicable
if (($method === "Credit Card" || $method === "Debit Card") && !empty($cardType)) {
    $message .= " (" . $cardType . ")";
}

$message .= " processed successfully.";

if (!empty($remarks)) {
    $message .= " Remarks: " . $remarks;
}

// Response array
$response = array(
    "status" => "success",
    "message" => $message
);

// Send JSON response
echo json_encode($response);
?>
